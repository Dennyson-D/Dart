class Cliente {
  String? nome;
  String? cpf;

  Cliente({this.nome, this.cpf});
}
